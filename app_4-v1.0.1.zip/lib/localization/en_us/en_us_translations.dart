final Map<String, String> enUs = {
  // Order Tracking Screen
  "lbl_10_xp": "10 XP",
  "lbl_20_xp": "20 XP",
  "lbl_40_xp": "40 XP",
  "lbl_healthy_w_bnin": "Healthy w bnin",
  "lbl_jewrly_store": "Jewrly store",
  "lbl_salon_racelle": "Salon Racelle",
  "lbl_stand_visited": "Stand visited",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
