import 'package:flutter/material.dart';
import 'package:app_4/presentation/order_tracking_screen/order_tracking_screen.dart';

class AppRoutes {
  static const String orderTrackingScreen = '/order_tracking_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        orderTrackingScreen: OrderTrackingScreen.builder,
        initialRoute: OrderTrackingScreen.builder
      };
}
