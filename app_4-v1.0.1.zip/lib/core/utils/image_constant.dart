class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // Order Tracking images
  static String imgArrowLeft = '$imagePath/img_arrow_left.svg';

  static String imgImage3 = '$imagePath/img_image_3.png';

  static String imgImage2 = '$imagePath/img_image_2.png';

  static String imgRectangle326 = '$imagePath/img_rectangle_326.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
