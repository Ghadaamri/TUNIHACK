/// This class is used in the [ordertracking_item_widget] screen.
class OrdertrackingItemModel {
  OrdertrackingItemModel({
    this.healthyWBnin,
    this.xPCounter,
    this.id,
  }) {
    healthyWBnin = healthyWBnin ?? "Healthy w bnin";
    xPCounter = xPCounter ?? "20 XP";
    id = id ?? "";
  }

  String? healthyWBnin;

  String? xPCounter;

  String? id;
}
