import '../order_tracking_screen/widgets/ordertracking_item_widget.dart';
import 'bloc/order_tracking_bloc.dart';
import 'models/order_tracking_model.dart';
import 'models/ordertracking_item_model.dart';
import 'package:app_4/core/app_export.dart';
import 'package:app_4/widgets/app_bar/appbar_leading_image.dart';
import 'package:app_4/widgets/app_bar/custom_app_bar.dart';
import 'package:flutter/material.dart';

class OrderTrackingScreen extends StatelessWidget {
  const OrderTrackingScreen({Key? key}) : super(key: key);

  static Widget builder(BuildContext context) {
    return BlocProvider<OrderTrackingBloc>(
        create: (context) => OrderTrackingBloc(
            OrderTrackingState(orderTrackingModelObj: OrderTrackingModel()))
          ..add(OrderTrackingInitialEvent()),
        child: OrderTrackingScreen());
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);
    return SafeArea(
        child: Scaffold(
            appBar: _buildAppBar(context),
            body: SizedBox(
                width: double.maxFinite,
                child: Column(children: [
                  CustomImageView(
                      imagePath: ImageConstant.imgImage3,
                      height: 395.v,
                      width: 375.h),
                  SizedBox(height: 24.v),
                  Align(
                      alignment: Alignment.centerLeft,
                      child: Padding(
                          padding: EdgeInsets.only(left: 12.h),
                          child: Text("lbl_stand_visited".tr,
                              style: theme.textTheme.titleLarge))),
                  SizedBox(height: 28.v),
                  _buildOrderTracking(context)
                ]))));
  }

  /// Section Widget
  PreferredSizeWidget _buildAppBar(BuildContext context) {
    return CustomAppBar(
        leadingWidth: double.maxFinite,
        leading: AppbarLeadingImage(
            imagePath: ImageConstant.imgArrowLeft,
            margin: EdgeInsets.fromLTRB(21.h, 12.v, 330.h, 12.v),
            onTap: () {
              onTapArrowLeft(context);
            }));
  }

  /// Section Widget
  Widget _buildOrderTracking(BuildContext context) {
    return BlocSelector<OrderTrackingBloc, OrderTrackingState,
            OrderTrackingModel?>(
        selector: (state) => state.orderTrackingModelObj,
        builder: (context, orderTrackingModelObj) {
          return ListView.separated(
              physics: NeverScrollableScrollPhysics(),
              shrinkWrap: true,
              separatorBuilder: (context, index) {
                return Padding(
                    padding: EdgeInsets.symmetric(vertical: 1.5.v),
                    child: SizedBox(
                        width: double.maxFinite,
                        child: Divider(
                            height: 1.v,
                            thickness: 1.v,
                            color: appTheme.gray200)));
              },
              itemCount:
                  orderTrackingModelObj?.ordertrackingItemList.length ?? 0,
              itemBuilder: (context, index) {
                OrdertrackingItemModel model =
                    orderTrackingModelObj?.ordertrackingItemList[index] ??
                        OrdertrackingItemModel();
                return OrdertrackingItemWidget(model);
              });
        });
  }

  /// Navigates to the previous screen.
  onTapArrowLeft(BuildContext context) {
    NavigatorService.goBack();
  }
}
