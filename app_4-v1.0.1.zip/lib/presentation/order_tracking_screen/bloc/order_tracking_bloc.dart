import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import '../models/ordertracking_item_model.dart';
import 'package:app_4/presentation/order_tracking_screen/models/order_tracking_model.dart';
part 'order_tracking_event.dart';
part 'order_tracking_state.dart';

/// A bloc that manages the state of a OrderTracking according to the event that is dispatched to it.
class OrderTrackingBloc extends Bloc<OrderTrackingEvent, OrderTrackingState> {
  OrderTrackingBloc(OrderTrackingState initialState) : super(initialState) {
    on<OrderTrackingInitialEvent>(_onInitialize);
  }

  _onInitialize(
    OrderTrackingInitialEvent event,
    Emitter<OrderTrackingState> emit,
  ) async {
    emit(state.copyWith(
        orderTrackingModelObj: state.orderTrackingModelObj
            ?.copyWith(ordertrackingItemList: fillOrdertrackingItemList())));
  }

  List<OrdertrackingItemModel> fillOrdertrackingItemList() {
    return [
      OrdertrackingItemModel(healthyWBnin: "Healthy w bnin", xPCounter: "20 XP")
    ];
  }
}
