import '../models/ordertracking_item_model.dart';
import 'package:app_4/core/app_export.dart';
import 'package:flutter/material.dart';

// ignore: must_be_immutable
class OrdertrackingItemWidget extends StatelessWidget {
  OrdertrackingItemWidget(
    this.ordertrackingItemModelObj, {
    Key? key,
  }) : super(
          key: key,
        );

  OrdertrackingItemModel ordertrackingItemModelObj;

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(
        horizontal: 26.h,
        vertical: 20.v,
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Padding(
            padding: EdgeInsets.only(left: 57.h),
            child: Text(
              ordertrackingItemModelObj.healthyWBnin!,
              style: theme.textTheme.titleMedium,
            ),
          ),
          Text(
            ordertrackingItemModelObj.xPCounter!,
            style: CustomTextStyles.titleMediumMontserratDeeporangeA700,
          ),
        ],
      ),
    );
  }
}
