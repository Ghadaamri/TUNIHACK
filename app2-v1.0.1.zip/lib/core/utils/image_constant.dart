class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // iPhone 13 Pro Max - Three images
  static String imgGroup1 = '$imagePath/img_group_1.svg';

  static String imgGroup3 = '$imagePath/img_group_3.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
