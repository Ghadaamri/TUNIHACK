final Map<String, String> enUs = {
  // iPhone 13 Pro Max - Three Screen
  "lbl_create_passward": "Create Passward",
  "lbl_create_username": "Create Username",
  "lbl_enter_email_id": "Enter Email Id",
  "lbl_sign_up": "Sign Up",
  "msg_create_account": "Create Account :)",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
