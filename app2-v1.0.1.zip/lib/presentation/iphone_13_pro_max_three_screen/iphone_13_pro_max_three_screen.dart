import 'bloc/iphone_13_pro_max_three_bloc.dart';
import 'models/iphone_13_pro_max_three_model.dart';
import 'package:app2/core/app_export.dart';
import 'package:app2/widgets/custom_elevated_button.dart';
import 'package:app2/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class Iphone13ProMaxThreeScreen extends StatelessWidget {
  const Iphone13ProMaxThreeScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone13ProMaxThreeBloc>(
      create: (context) => Iphone13ProMaxThreeBloc(Iphone13ProMaxThreeState(
        iphone13ProMaxThreeModelObj: Iphone13ProMaxThreeModel(),
      ))
        ..add(Iphone13ProMaxThreeInitialEvent()),
      child: Iphone13ProMaxThreeScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return BlocBuilder<Iphone13ProMaxThreeBloc, Iphone13ProMaxThreeState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: Container(
              width: double.maxFinite,
              padding: EdgeInsets.symmetric(vertical: 27.v),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Padding(
                    padding: EdgeInsets.only(left: 21.h),
                    child: CustomIconButton(
                      height: 48.adaptSize,
                      width: 48.adaptSize,
                      padding: EdgeInsets.all(15.h),
                      child: CustomImageView(
                        imagePath: ImageConstant.imgGroup1,
                      ),
                    ),
                  ),
                  SizedBox(height: 8.v),
                  Expanded(
                    child: Container(
                      width: double.maxFinite,
                      padding: EdgeInsets.symmetric(
                        horizontal: 25.h,
                        vertical: 14.v,
                      ),
                      decoration: BoxDecoration(
                        image: DecorationImage(
                          image: AssetImage(
                            ImageConstant.imgGroup3,
                          ),
                          fit: BoxFit.cover,
                        ),
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SizedBox(height: 14.v),
                          SizedBox(
                            width: 161.h,
                            child: Text(
                              "msg_create_account".tr,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              style: theme.textTheme.headlineLarge,
                            ),
                          ),
                          SizedBox(height: 64.v),
                          Padding(
                            padding: EdgeInsets.only(left: 14.h),
                            child: Text(
                              "lbl_enter_email_id".tr,
                              style: theme.textTheme.headlineMedium,
                            ),
                          ),
                          SizedBox(height: 48.v),
                          Align(
                            alignment: Alignment.center,
                            child: Divider(
                              indent: 14.h,
                              endIndent: 15.h,
                            ),
                          ),
                          SizedBox(height: 42.v),
                          Padding(
                            padding: EdgeInsets.only(left: 14.h),
                            child: Text(
                              "lbl_create_username".tr,
                              style: theme.textTheme.headlineMedium,
                            ),
                          ),
                          SizedBox(height: 49.v),
                          Align(
                            alignment: Alignment.center,
                            child: Divider(
                              indent: 14.h,
                              endIndent: 15.h,
                            ),
                          ),
                          SizedBox(height: 55.v),
                          Padding(
                            padding: EdgeInsets.only(left: 17.h),
                            child: Text(
                              "lbl_create_passward".tr,
                              style: theme.textTheme.headlineMedium,
                            ),
                          ),
                          SizedBox(height: 49.v),
                          Align(
                            alignment: Alignment.center,
                            child: Divider(
                              indent: 14.h,
                              endIndent: 15.h,
                            ),
                          ),
                          Spacer(),
                          CustomElevatedButton(
                            width: 229.h,
                            text: "lbl_sign_up".tr,
                            alignment: Alignment.center,
                          ),
                        ],
                      ),
                    ),
                  ),
                  SizedBox(height: 5.v),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
