// ignore_for_file: must_be_immutable

part of 'iphone_13_pro_max_three_bloc.dart';

/// Represents the state of Iphone13ProMaxThree in the application.
class Iphone13ProMaxThreeState extends Equatable {
  Iphone13ProMaxThreeState({this.iphone13ProMaxThreeModelObj});

  Iphone13ProMaxThreeModel? iphone13ProMaxThreeModelObj;

  @override
  List<Object?> get props => [
        iphone13ProMaxThreeModelObj,
      ];
  Iphone13ProMaxThreeState copyWith(
      {Iphone13ProMaxThreeModel? iphone13ProMaxThreeModelObj}) {
    return Iphone13ProMaxThreeState(
      iphone13ProMaxThreeModelObj:
          iphone13ProMaxThreeModelObj ?? this.iphone13ProMaxThreeModelObj,
    );
  }
}
