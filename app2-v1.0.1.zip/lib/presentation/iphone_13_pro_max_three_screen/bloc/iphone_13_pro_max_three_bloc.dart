import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:app2/presentation/iphone_13_pro_max_three_screen/models/iphone_13_pro_max_three_model.dart';
part 'iphone_13_pro_max_three_event.dart';
part 'iphone_13_pro_max_three_state.dart';

/// A bloc that manages the state of a Iphone13ProMaxThree according to the event that is dispatched to it.
class Iphone13ProMaxThreeBloc
    extends Bloc<Iphone13ProMaxThreeEvent, Iphone13ProMaxThreeState> {
  Iphone13ProMaxThreeBloc(Iphone13ProMaxThreeState initialState)
      : super(initialState) {
    on<Iphone13ProMaxThreeInitialEvent>(_onInitialize);
  }

  _onInitialize(
    Iphone13ProMaxThreeInitialEvent event,
    Emitter<Iphone13ProMaxThreeState> emit,
  ) async {}
}
