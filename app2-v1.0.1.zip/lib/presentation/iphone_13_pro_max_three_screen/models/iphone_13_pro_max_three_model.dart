// ignore_for_file: must_be_immutable

import 'package:equatable/equatable.dart';

/// This class defines the variables used in the [iphone_13_pro_max_three_screen],
/// and is typically used to hold data that is passed between different parts of the application.
class Iphone13ProMaxThreeModel extends Equatable {
  Iphone13ProMaxThreeModel() {}

  Iphone13ProMaxThreeModel copyWith() {
    return Iphone13ProMaxThreeModel();
  }

  @override
  List<Object?> get props => [];
}
