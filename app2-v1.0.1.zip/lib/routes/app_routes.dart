import 'package:flutter/material.dart';
import 'package:app2/presentation/iphone_13_pro_max_three_screen/iphone_13_pro_max_three_screen.dart';

class AppRoutes {
  static const String iphone13ProMaxThreeScreen =
      '/iphone_13_pro_max_three_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        iphone13ProMaxThreeScreen: Iphone13ProMaxThreeScreen.builder,
        initialRoute: Iphone13ProMaxThreeScreen.builder
      };
}
