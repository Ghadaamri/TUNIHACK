import 'package:app2/core/app_export.dart';

class ApiClient {}
