import 'package:flutter/material.dart';
import 'package:app1/presentation/iphone_13_pro_max_two_screen/iphone_13_pro_max_two_screen.dart';

class AppRoutes {
  static const String iphone13ProMaxTwoScreen = '/iphone_13_pro_max_two_screen';

  static const String initialRoute = '/initialRoute';

  static Map<String, WidgetBuilder> get routes => {
        iphone13ProMaxTwoScreen: Iphone13ProMaxTwoScreen.builder,
        initialRoute: Iphone13ProMaxTwoScreen.builder
      };
}
