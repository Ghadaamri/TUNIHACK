class ImageConstant {
  // Image folder path
  static String imagePath = 'assets/images';

  // iPhone 13 Pro Max - Two images
  static String imgGroup2 = '$imagePath/img_group_2.svg';

  static String imgUnion = '$imagePath/img_union.png';

  static String imageNotFound = 'assets/images/image_not_found.png';
}
