import 'bloc/iphone_13_pro_max_two_bloc.dart';
import 'models/iphone_13_pro_max_two_model.dart';
import 'package:app1/core/app_export.dart';
import 'package:app1/widgets/custom_elevated_button.dart';
import 'package:app1/widgets/custom_icon_button.dart';
import 'package:flutter/material.dart';

class Iphone13ProMaxTwoScreen extends StatelessWidget {
  const Iphone13ProMaxTwoScreen({Key? key})
      : super(
          key: key,
        );

  static Widget builder(BuildContext context) {
    return BlocProvider<Iphone13ProMaxTwoBloc>(
      create: (context) => Iphone13ProMaxTwoBloc(Iphone13ProMaxTwoState(
        iphone13ProMaxTwoModelObj: Iphone13ProMaxTwoModel(),
      ))
        ..add(Iphone13ProMaxTwoInitialEvent()),
      child: Iphone13ProMaxTwoScreen(),
    );
  }

  @override
  Widget build(BuildContext context) {
    mediaQueryData = MediaQuery.of(context);

    return BlocBuilder<Iphone13ProMaxTwoBloc, Iphone13ProMaxTwoState>(
      builder: (context, state) {
        return SafeArea(
          child: Scaffold(
            body: SizedBox(
              width: double.maxFinite,
              child: Column(
                children: [
                  SizedBox(height: 24.v),
                  Expanded(
                    child: SingleChildScrollView(
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Padding(
                            padding: EdgeInsets.only(left: 29.h),
                            child: CustomIconButton(
                              height: 48.adaptSize,
                              width: 48.adaptSize,
                              padding: EdgeInsets.all(15.h),
                              child: CustomImageView(
                                imagePath: ImageConstant.imgGroup2,
                              ),
                            ),
                          ),
                          SizedBox(height: 65.v),
                          Padding(
                            padding: EdgeInsets.only(left: 38.h),
                            child: Text(
                              "lbl_welcome_back".tr,
                              style: theme.textTheme.headlineLarge,
                            ),
                          ),
                          SizedBox(height: 6.v),
                          Padding(
                            padding: EdgeInsets.only(left: 38.h),
                            child: Text(
                              "msg_enter_your_username".tr,
                              style: theme.textTheme.titleMedium,
                            ),
                          ),
                          SizedBox(height: 88.v),
                          SizedBox(
                            height: 713.v,
                            width: double.maxFinite,
                            child: Stack(
                              alignment: Alignment.topLeft,
                              children: [
                                CustomImageView(
                                  imagePath: ImageConstant.imgUnion,
                                  height: 633.v,
                                  width: 428.h,
                                  alignment: Alignment.topCenter,
                                ),
                                _buildEight(context),
                              ],
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }

  /// Section Widget
  Widget _buildEight(BuildContext context) {
    return Align(
      alignment: Alignment.topLeft,
      child: Padding(
        padding: EdgeInsets.only(
          left: 29.h,
          top: 97.v,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 14.h),
                child: Text(
                  "lbl_username".tr,
                  style: theme.textTheme.headlineMedium,
                ),
              ),
            ),
            SizedBox(height: 40.v),
            Divider(
              endIndent: 3.h,
            ),
            SizedBox(height: 65.v),
            Align(
              alignment: Alignment.centerLeft,
              child: Padding(
                padding: EdgeInsets.only(left: 14.h),
                child: Text(
                  "lbl_password".tr,
                  style: theme.textTheme.headlineMedium,
                ),
              ),
            ),
            SizedBox(height: 39.v),
            Divider(
              indent: 3.h,
            ),
            SizedBox(height: 94.v),
            CustomElevatedButton(
              width: 229.h,
              text: "lbl_login".tr,
            ),
            SizedBox(height: 25.v),
            Text(
              "msg_forgotten_passwoard".tr,
              style: theme.textTheme.bodyMedium,
            ),
            SizedBox(height: 3.v),
            Text(
              "msg_or_create_a_new".tr,
              style: theme.textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }
}
