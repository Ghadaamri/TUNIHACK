import 'package:equatable/equatable.dart';
import 'package:flutter/material.dart';
import '/core/app_export.dart';
import 'package:app1/presentation/iphone_13_pro_max_two_screen/models/iphone_13_pro_max_two_model.dart';
part 'iphone_13_pro_max_two_event.dart';
part 'iphone_13_pro_max_two_state.dart';

/// A bloc that manages the state of a Iphone13ProMaxTwo according to the event that is dispatched to it.
class Iphone13ProMaxTwoBloc
    extends Bloc<Iphone13ProMaxTwoEvent, Iphone13ProMaxTwoState> {
  Iphone13ProMaxTwoBloc(Iphone13ProMaxTwoState initialState)
      : super(initialState) {
    on<Iphone13ProMaxTwoInitialEvent>(_onInitialize);
  }

  _onInitialize(
    Iphone13ProMaxTwoInitialEvent event,
    Emitter<Iphone13ProMaxTwoState> emit,
  ) async {}
}
