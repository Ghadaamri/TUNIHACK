// ignore_for_file: must_be_immutable

part of 'iphone_13_pro_max_two_bloc.dart';

/// Represents the state of Iphone13ProMaxTwo in the application.
class Iphone13ProMaxTwoState extends Equatable {
  Iphone13ProMaxTwoState({this.iphone13ProMaxTwoModelObj});

  Iphone13ProMaxTwoModel? iphone13ProMaxTwoModelObj;

  @override
  List<Object?> get props => [
        iphone13ProMaxTwoModelObj,
      ];
  Iphone13ProMaxTwoState copyWith(
      {Iphone13ProMaxTwoModel? iphone13ProMaxTwoModelObj}) {
    return Iphone13ProMaxTwoState(
      iphone13ProMaxTwoModelObj:
          iphone13ProMaxTwoModelObj ?? this.iphone13ProMaxTwoModelObj,
    );
  }
}
