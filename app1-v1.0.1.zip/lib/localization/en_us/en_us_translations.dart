final Map<String, String> enUs = {
  // iPhone 13 Pro Max - Two Screen
  "lbl_login": "LOGIN",
  "lbl_password": "Password",
  "lbl_username": "Username",
  "lbl_welcome_back": "Welcome Back!",
  "msg_enter_your_username": "Enter Your Username & Password",
  "msg_forgotten_passwoard": "Forgotten Passwoard?",
  "msg_or_create_a_new": "Or Create a New Account",

// Network Error String
  "msg_network_err": "Network Error",
  "msg_something_went_wrong": "Something Went Wrong!",
};
